from .finite_automata.machine import DeterministicFiniteAutomata as DFA
from .finite_automata.machine import NonDeterministicFiniteAutomata as NDFA
